
#include <touchgfx/hal/GPIO.hpp>

/* USER CODE BEGIN user includes */

/* USER CODE END user includes */

using namespace touchgfx;

void GPIO::init()
{
}

void GPIO::set(GPIO_ID id)
{
}

void GPIO::clear(GPIO_ID id)
{
}

void GPIO::toggle(GPIO_ID id)
{
}

bool GPIO::get(GPIO_ID id)
{
  return true;
}
